from field import *


selected_methods = {
    "cannon": lambda field: Field.create_cannon(field),
}
